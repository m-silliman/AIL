﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.buttonShowMessageFinder = New System.Windows.Forms.Button()
        Me.label4 = New System.Windows.Forms.Label()
        Me.textBoxFeedback = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.textBoxInputFile = New System.Windows.Forms.TextBox()
        Me.checkBoxUseInputFile = New System.Windows.Forms.CheckBox()
        Me.comboBoxEndpointScript = New System.Windows.Forms.ComboBox()
        Me.buttonExecuteEndpoint = New System.Windows.Forms.Button()
        Me.checkBoxAutoBreak = New System.Windows.Forms.CheckBox()
        Me.comboBoxTaskScript = New System.Windows.Forms.ComboBox()
        Me.comboBoxExecuteScript = New System.Windows.Forms.ComboBox()
        Me.buttonExecuteTaskCmd = New System.Windows.Forms.Button()
        Me.buttonExecuteCmd = New System.Windows.Forms.Button()
        Me.label2 = New System.Windows.Forms.Label()
        Me.tbScriptDataToSend = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'buttonShowMessageFinder
        '
        Me.buttonShowMessageFinder.Location = New System.Drawing.Point(12, 109)
        Me.buttonShowMessageFinder.Name = "buttonShowMessageFinder"
        Me.buttonShowMessageFinder.Size = New System.Drawing.Size(121, 41)
        Me.buttonShowMessageFinder.TabIndex = 30
        Me.buttonShowMessageFinder.Text = "Show Message Finder"
        Me.buttonShowMessageFinder.UseVisualStyleBackColor = True
        '
        'label4
        '
        Me.label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.label4.AutoSize = True
        Me.label4.Location = New System.Drawing.Point(10, 320)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(55, 13)
        Me.label4.TabIndex = 29
        Me.label4.Text = "Feedback"
        '
        'textBoxFeedback
        '
        Me.textBoxFeedback.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxFeedback.Location = New System.Drawing.Point(12, 339)
        Me.textBoxFeedback.Multiline = True
        Me.textBoxFeedback.Name = "textBoxFeedback"
        Me.textBoxFeedback.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.textBoxFeedback.Size = New System.Drawing.Size(621, 63)
        Me.textBoxFeedback.TabIndex = 28
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(256, 114)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(151, 13)
        Me.label3.TabIndex = 27
        Me.label3.Text = "Input File (Abolute Path Name)"
        '
        'textBoxInputFile
        '
        Me.textBoxInputFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.textBoxInputFile.Location = New System.Drawing.Point(257, 130)
        Me.textBoxInputFile.Name = "textBoxInputFile"
        Me.textBoxInputFile.Size = New System.Drawing.Size(376, 20)
        Me.textBoxInputFile.TabIndex = 26
        '
        'checkBoxUseInputFile
        '
        Me.checkBoxUseInputFile.AutoSize = True
        Me.checkBoxUseInputFile.Location = New System.Drawing.Point(139, 130)
        Me.checkBoxUseInputFile.Name = "checkBoxUseInputFile"
        Me.checkBoxUseInputFile.Size = New System.Drawing.Size(91, 17)
        Me.checkBoxUseInputFile.TabIndex = 25
        Me.checkBoxUseInputFile.Text = "Use Input File"
        Me.checkBoxUseInputFile.UseVisualStyleBackColor = True
        '
        'comboBoxEndpointScript
        '
        Me.comboBoxEndpointScript.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxEndpointScript.DisplayMember = "Name"
        Me.comboBoxEndpointScript.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxEndpointScript.FormattingEnabled = True
        Me.comboBoxEndpointScript.Location = New System.Drawing.Point(139, 74)
        Me.comboBoxEndpointScript.Name = "comboBoxEndpointScript"
        Me.comboBoxEndpointScript.Size = New System.Drawing.Size(494, 21)
        Me.comboBoxEndpointScript.TabIndex = 24
        '
        'buttonExecuteEndpoint
        '
        Me.buttonExecuteEndpoint.Location = New System.Drawing.Point(12, 74)
        Me.buttonExecuteEndpoint.Name = "buttonExecuteEndpoint"
        Me.buttonExecuteEndpoint.Size = New System.Drawing.Size(121, 21)
        Me.buttonExecuteEndpoint.TabIndex = 23
        Me.buttonExecuteEndpoint.Text = "Execute Endpoint"
        Me.buttonExecuteEndpoint.UseVisualStyleBackColor = True
        '
        'checkBoxAutoBreak
        '
        Me.checkBoxAutoBreak.AutoSize = True
        Me.checkBoxAutoBreak.Checked = True
        Me.checkBoxAutoBreak.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkBoxAutoBreak.Location = New System.Drawing.Point(139, 110)
        Me.checkBoxAutoBreak.Name = "checkBoxAutoBreak"
        Me.checkBoxAutoBreak.Size = New System.Drawing.Size(79, 17)
        Me.checkBoxAutoBreak.TabIndex = 22
        Me.checkBoxAutoBreak.Text = "Auto Break"
        Me.checkBoxAutoBreak.UseVisualStyleBackColor = True
        '
        'comboBoxTaskScript
        '
        Me.comboBoxTaskScript.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxTaskScript.DisplayMember = "Name"
        Me.comboBoxTaskScript.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxTaskScript.FormattingEnabled = True
        Me.comboBoxTaskScript.Location = New System.Drawing.Point(139, 44)
        Me.comboBoxTaskScript.Name = "comboBoxTaskScript"
        Me.comboBoxTaskScript.Size = New System.Drawing.Size(494, 21)
        Me.comboBoxTaskScript.TabIndex = 21
        '
        'comboBoxExecuteScript
        '
        Me.comboBoxExecuteScript.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.comboBoxExecuteScript.DisplayMember = "Name"
        Me.comboBoxExecuteScript.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBoxExecuteScript.FormattingEnabled = True
        Me.comboBoxExecuteScript.Location = New System.Drawing.Point(139, 14)
        Me.comboBoxExecuteScript.Name = "comboBoxExecuteScript"
        Me.comboBoxExecuteScript.Size = New System.Drawing.Size(494, 21)
        Me.comboBoxExecuteScript.TabIndex = 20
        '
        'buttonExecuteTaskCmd
        '
        Me.buttonExecuteTaskCmd.Location = New System.Drawing.Point(12, 44)
        Me.buttonExecuteTaskCmd.Name = "buttonExecuteTaskCmd"
        Me.buttonExecuteTaskCmd.Size = New System.Drawing.Size(121, 21)
        Me.buttonExecuteTaskCmd.TabIndex = 19
        Me.buttonExecuteTaskCmd.Text = "Execute Task"
        Me.buttonExecuteTaskCmd.UseVisualStyleBackColor = True
        '
        'buttonExecuteCmd
        '
        Me.buttonExecuteCmd.Location = New System.Drawing.Point(12, 15)
        Me.buttonExecuteCmd.Name = "buttonExecuteCmd"
        Me.buttonExecuteCmd.Size = New System.Drawing.Size(121, 20)
        Me.buttonExecuteCmd.TabIndex = 18
        Me.buttonExecuteCmd.Text = "Execute Event"
        Me.buttonExecuteCmd.UseVisualStyleBackColor = True
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(13, 93)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(0, 13)
        Me.label2.TabIndex = 17
        '
        'tbScriptDataToSend
        '
        Me.tbScriptDataToSend.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tbScriptDataToSend.Location = New System.Drawing.Point(12, 168)
        Me.tbScriptDataToSend.Multiline = True
        Me.tbScriptDataToSend.Name = "tbScriptDataToSend"
        Me.tbScriptDataToSend.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.tbScriptDataToSend.Size = New System.Drawing.Size(621, 144)
        Me.tbScriptDataToSend.TabIndex = 16
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(645, 426)
        Me.Controls.Add(Me.buttonShowMessageFinder)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.textBoxFeedback)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.textBoxInputFile)
        Me.Controls.Add(Me.checkBoxUseInputFile)
        Me.Controls.Add(Me.comboBoxEndpointScript)
        Me.Controls.Add(Me.buttonExecuteEndpoint)
        Me.Controls.Add(Me.checkBoxAutoBreak)
        Me.Controls.Add(Me.comboBoxTaskScript)
        Me.Controls.Add(Me.comboBoxExecuteScript)
        Me.Controls.Add(Me.buttonExecuteTaskCmd)
        Me.Controls.Add(Me.buttonExecuteCmd)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.tbScriptDataToSend)
        Me.Name = "FormMain"
        Me.Text = "Script Test Form (VB)"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents buttonShowMessageFinder As Button
    Private WithEvents label4 As Label
    Private WithEvents textBoxFeedback As TextBox
    Private WithEvents label3 As Label
    Private WithEvents textBoxInputFile As TextBox
    Private WithEvents checkBoxUseInputFile As CheckBox
    Private WithEvents comboBoxEndpointScript As ComboBox
    Private WithEvents buttonExecuteEndpoint As Button
    Private WithEvents checkBoxAutoBreak As CheckBox
    Private WithEvents comboBoxTaskScript As ComboBox
    Private WithEvents comboBoxExecuteScript As ComboBox
    Private WithEvents buttonExecuteTaskCmd As Button
    Private WithEvents buttonExecuteCmd As Button
    Private WithEvents label2 As Label
    Private WithEvents tbScriptDataToSend As TextBox
End Class

﻿
Partial Public Class FormMain
    Inherits Form
    Public Sub New()
        InitializeComponent()

        Dim type = GetType(DM.Library.Domain.Interfaces.IDispatchManagerScript)
        Dim types = AppDomain.CurrentDomain.GetAssemblies().SelectMany(Function(s) s.GetTypes()).Where(Function(p) type.IsAssignableFrom(p))

        comboBoxExecuteScript.DataSource = types.ToList()

        Dim typeT = GetType(DM.Library.Domain.Interfaces.IDispatchTaskScript)
        Dim typesT = AppDomain.CurrentDomain.GetAssemblies().SelectMany(Function(s) s.GetTypes()).Where(Function(p) typeT.IsAssignableFrom(p))

        Me.comboBoxTaskScript.DataSource = typesT.ToList()

        Dim typeE = GetType(DM.Library.Domain.Interfaces.IEndpointScript)
        Dim typesE = AppDomain.CurrentDomain.GetAssemblies().SelectMany(Function(s) s.GetTypes()).Where(Function(p) typeE.IsAssignableFrom(p))

        Me.comboBoxEndpointScript.DataSource = typesE.ToList()

        If System.IO.File.Exists(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt") Then
            tbScriptDataToSend.Text = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt")
        End If
    End Sub

    Private Sub buttonExecuteCmd_Click(sender As Object, e As EventArgs) Handles buttonExecuteCmd.Click
        System.IO.File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt", tbScriptDataToSend.Text)

        Dim t As Type = TryCast(comboBoxExecuteScript.SelectedItem, Type)

        Dim script As DM.Library.Domain.Interfaces.IDispatchManagerScript = DirectCast(Activator.CreateInstance(t), DM.Library.Domain.Interfaces.IDispatchManagerScript)

        If checkBoxAutoBreak.Checked Then
            System.Diagnostics.Debugger.Break()
        End If

        Dim v As New DM.Library.Domain.DispatchMessage()
        v.Data = GetText()
        Dim ctx = New DM.Library.Domain.ScriptContext(v)
        ctx.DataMapper = New DM.Library.Mapper()
        ctx.Queue = New DM.Library.MessageQ.FileWriter()

        script.Execute(ctx)

    End Sub



    Private Sub buttonExecuteTaskCmd_Click(sender As Object, e As EventArgs) Handles buttonExecuteTaskCmd.Click
        System.IO.File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt", tbScriptDataToSend.Text)

        Dim t As Type = TryCast(comboBoxTaskScript.SelectedItem, Type)

        Dim script As DM.Library.Domain.Interfaces.IDispatchTaskScript = DirectCast(Activator.CreateInstance(t), DM.Library.Domain.Interfaces.IDispatchTaskScript)

        If checkBoxAutoBreak.Checked Then
            System.Diagnostics.Debugger.Break()
        End If

        Dim ctx As New DM.Library.Domain.TaskContext()
        ctx.DataMapper = New DM.Library.Mapper()
        ctx.Queue = New DM.Library.MessageQ.FileWriter()

        script.Execute(ctx)

    End Sub

    Public Function GetText() As String
        Dim text As String = ""
        If checkBoxUseInputFile.Checked Then
            If System.IO.File.Exists(textBoxInputFile.Text) Then
                text = System.IO.File.ReadAllText(textBoxInputFile.Text)
            End If
        Else
            text = tbScriptDataToSend.Text
        End If


        Return text
    End Function

    Private Sub buttonExecuteEndpoint_Click(sender As Object, e As EventArgs) Handles buttonExecuteEndpoint.Click
        System.IO.File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt", tbScriptDataToSend.Text)

        Dim t As Type = TryCast(Me.comboBoxEndpointScript.SelectedItem, Type)

        Dim script As DM.Library.Domain.Interfaces.IEndpointScript = DirectCast(Activator.CreateInstance(t), DM.Library.Domain.Interfaces.IEndpointScript)

        If checkBoxAutoBreak.Checked Then
            System.Diagnostics.Debugger.Break()
        End If

        Dim ctx = New DM.Library.Domain.EndpointContext()
        ctx.DataMapper = New DM.Library.Mapper()
        ctx.Queue = New DM.Library.MessageQ.FileWriter()
        ctx.Url = "http://localhost"
        ctx.RemoteHost = "localhost"
        ctx.Content = GetText()

        Dim obj = script.Execute(ctx)

        textBoxFeedback.Text = Newtonsoft.Json.JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented)

    End Sub

    Private Sub button1_Click(sender As Object, e As EventArgs)
        Using db = DM.Library.DataAccess.SqlCommandFactory.GetDatabase("AiDb")
            Dim sql As String = vbCr & vbLf & "SELECT [Id]" & vbCr & vbLf & "      ,[CreateTime]" & vbCr & vbLf & "      ,[Name]" & vbCr & vbLf & "      ,[Source]" & vbCr & vbLf & "      ,[Data]" & vbCr & vbLf & "      ,[Status]" & vbCr & vbLf & "      ,[ProcessedTime]" & vbCr & vbLf & "      ,[Errors]" & vbCr & vbLf & "      ,[DoNotProcessUntil]" & vbCr & vbLf & "  FROM [mes].[DispatchMessage]" & vbCr & vbLf & "WHERE [Id] = 6074409" & vbCr & vbLf
            Dim list = DM.Library.DataAccess.SqlCommandFactory(Of DM.Library.Domain.DispatchMessage).ExecuteQuery(db, True, sql, Nothing).FirstOrDefault()



            System.IO.File.WriteAllText("C:\temp\msg.txt", list.Data)
        End Using
    End Sub

    Private Sub buttonShowMessageFinder_Click(sender As Object, e As EventArgs) Handles buttonShowMessageFinder.Click
        Dim msg As New FormFindMessages()

        AddHandler msg.ItemSelected, AddressOf msg_ItemSelected
        AddHandler msg.SetFileNameTargetName, AddressOf msg_SetFileNameTargetName

        msg.Show()

    End Sub

    Private Sub msg_SetFileNameTargetName(sender As Object, e As FormFindMessages.ItemSelectedEventArgs)
        textBoxInputFile.Text = e.ContextData
    End Sub

    Private Sub msg_ItemSelected(sender As Object, e As FormFindMessages.ItemSelectedEventArgs)
        tbScriptDataToSend.Text = e.ContextData
    End Sub

End Class



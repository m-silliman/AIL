﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormFindMessages
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.listViewFoundMessages = New System.Windows.Forms.ListView()
        Me.columnHeaderDate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderStatus = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderSource = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeaderData = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.buttonPasteText = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.buttonFind = New System.Windows.Forms.Button()
        Me.txtFilterText = New System.Windows.Forms.TextBox()
        Me.cmbMessageTypes = New System.Windows.Forms.ComboBox()
        Me.saveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.SuspendLayout()
        '
        'listViewFoundMessages
        '
        Me.listViewFoundMessages.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.listViewFoundMessages.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.columnHeaderDate, Me.columnHeaderStatus, Me.columnHeaderSource, Me.columnHeaderData})
        Me.listViewFoundMessages.FullRowSelect = True
        Me.listViewFoundMessages.Location = New System.Drawing.Point(12, 35)
        Me.listViewFoundMessages.Name = "listViewFoundMessages"
        Me.listViewFoundMessages.Size = New System.Drawing.Size(1027, 240)
        Me.listViewFoundMessages.TabIndex = 6
        Me.listViewFoundMessages.UseCompatibleStateImageBehavior = False
        Me.listViewFoundMessages.View = System.Windows.Forms.View.Details
        '
        'columnHeaderDate
        '
        Me.columnHeaderDate.Text = "Date"
        Me.columnHeaderDate.Width = 120
        '
        'columnHeaderStatus
        '
        Me.columnHeaderStatus.Text = "Status"
        Me.columnHeaderStatus.Width = 121
        '
        'columnHeaderSource
        '
        Me.columnHeaderSource.Text = "Source"
        Me.columnHeaderSource.Width = 126
        '
        'columnHeaderData
        '
        Me.columnHeaderData.Text = "Data"
        Me.columnHeaderData.Width = 387
        '
        'buttonPasteText
        '
        Me.buttonPasteText.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.buttonPasteText.Location = New System.Drawing.Point(12, 281)
        Me.buttonPasteText.Name = "buttonPasteText"
        Me.buttonPasteText.Size = New System.Drawing.Size(105, 23)
        Me.buttonPasteText.TabIndex = 11
        Me.buttonPasteText.Text = "Paste Text"
        Me.buttonPasteText.UseVisualStyleBackColor = True
        '
        'button1
        '
        Me.button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.button1.Location = New System.Drawing.Point(913, 281)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(126, 23)
        Me.button1.TabIndex = 10
        Me.button1.Text = "Export Data To File..."
        Me.button1.UseVisualStyleBackColor = True
        '
        'buttonFind
        '
        Me.buttonFind.Location = New System.Drawing.Point(12, 6)
        Me.buttonFind.Name = "buttonFind"
        Me.buttonFind.Size = New System.Drawing.Size(75, 23)
        Me.buttonFind.TabIndex = 9
        Me.buttonFind.Text = "Find"
        Me.buttonFind.UseVisualStyleBackColor = True
        '
        'txtFilterText
        '
        Me.txtFilterText.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFilterText.Location = New System.Drawing.Point(93, 8)
        Me.txtFilterText.Name = "txtFilterText"
        Me.txtFilterText.Size = New System.Drawing.Size(266, 20)
        Me.txtFilterText.TabIndex = 8
        '
        'cmbMessageTypes
        '
        Me.cmbMessageTypes.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmbMessageTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMessageTypes.FormattingEnabled = True
        Me.cmbMessageTypes.Location = New System.Drawing.Point(365, 7)
        Me.cmbMessageTypes.Name = "cmbMessageTypes"
        Me.cmbMessageTypes.Size = New System.Drawing.Size(674, 21)
        Me.cmbMessageTypes.TabIndex = 7
        '
        'FormFindMessages
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1051, 316)
        Me.Controls.Add(Me.listViewFoundMessages)
        Me.Controls.Add(Me.buttonPasteText)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.buttonFind)
        Me.Controls.Add(Me.txtFilterText)
        Me.Controls.Add(Me.cmbMessageTypes)
        Me.Name = "FormFindMessages"
        Me.Text = "FormFindMessages"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents listViewFoundMessages As ListView
    Private WithEvents columnHeaderDate As ColumnHeader
    Private WithEvents columnHeaderStatus As ColumnHeader
    Private WithEvents columnHeaderSource As ColumnHeader
    Private WithEvents columnHeaderData As ColumnHeader
    Private WithEvents buttonPasteText As Button
    Private WithEvents button1 As Button
    Private WithEvents buttonFind As Button
    Private WithEvents txtFilterText As TextBox
    Private WithEvents cmbMessageTypes As ComboBox
    Private WithEvents saveFileDialog1 As SaveFileDialog
End Class

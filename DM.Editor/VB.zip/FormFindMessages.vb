﻿Partial Public Class FormFindMessages
    Inherits Form
    Public Sub New()
        InitializeComponent()
    End Sub

    Public Class ItemSelectedEventArgs
        Inherits EventArgs
        Public Property ContextData() As String
            Get
                Return m_ContextData
            End Get
            Set
                m_ContextData = Value
            End Set
        End Property
        Private m_ContextData As String
    End Class

    Public Event ItemSelected As EventHandler(Of ItemSelectedEventArgs)

    Public Event SetFileNameTargetName As EventHandler(Of ItemSelectedEventArgs)

    Protected Overrides Sub OnLoad(e As EventArgs)
        MyBase.OnLoad(e)

        Dim type = GetType(DM.Library.Domain.Interfaces.IDispatchManagerScript)
        Dim types = AppDomain.CurrentDomain.GetAssemblies().SelectMany(Function(s) s.GetTypes()).Where(Function(p) type.IsAssignableFrom(p))

        cmbMessageTypes.DisplayMember = "Name"
        cmbMessageTypes.DataSource = types.ToList()
    End Sub

    Private Sub buttonFind_Click(sender As Object, e As EventArgs) Handles buttonFind.Click
        Dim messageName As String = cmbMessageTypes.Text
        Dim filterText As String = txtFilterText.Text

        Dim qMessages As List(Of DM.Library.Domain.DispatchMessage) = DM.Library.DataAccess.Adapter.DispatchMessageAdapter.GetPreviousMessageTypes(cmbMessageTypes.Text, 1000)

        If Not String.IsNullOrEmpty(filterText) Then
            qMessages = qMessages.Where(Function(a) a.Data.Contains(filterText)).ToList()
        End If

        listViewFoundMessages.Items.Clear()
        For Each msg As DM.Library.Domain.DispatchMessage In qMessages.OrderByDescending(Function(o) o.CreateTime)
            Dim lviItem As ListViewItem = listViewFoundMessages.Items.Add(msg.CreateTime.ToShortDateString() + " " + msg.CreateTime.ToShortTimeString())
            lviItem.SubItems.Add(msg.CreateTime.ToShortDateString() + " " + msg.CreateTime.ToShortTimeString())
            lviItem.SubItems.Add(msg.Status)
            lviItem.SubItems.Add(msg.Data)

            lviItem.Tag = msg
        Next
    End Sub

    Public Function GetText() As String
        Dim index As Integer = listViewFoundMessages.SelectedItems(0).SubItems.Count - 1
        Return listViewFoundMessages.SelectedItems(0).SubItems(index).Text
    End Function

    Private Sub listViewFoundMessages_DoubleClick(sender As Object, e As EventArgs) Handles listViewFoundMessages.DoubleClick
        If listViewFoundMessages.SelectedItems.Count = 0 Then
            Return
        End If

        Clipboard.SetText(GetText(), TextDataFormat.Text)
        Dim a As New ItemSelectedEventArgs()
        a.ContextData = GetText()

        RaiseEvent ItemSelected(Me, a)
    End Sub

    Private Sub buttonPasteText_Click(sender As Object, e As EventArgs) Handles buttonPasteText.Click

        Dim a As New ItemSelectedEventArgs()
        a.ContextData = GetText()

        RaiseEvent ItemSelected(Me, a)
    End Sub

    Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
        If saveFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            System.IO.File.WriteAllText(saveFileDialog1.FileName, GetText())
            MessageBox.Show("File saved: " + saveFileDialog1.FileName)

            Dim a As New ItemSelectedEventArgs()
            a.ContextData = saveFileDialog1.FileName

            RaiseEvent SetFileNameTargetName(Me, a)
        End If
    End Sub

End Class

'=======================================================
'Service provided by Telerik (www.telerik.com)
'Conversion powered by NRefactory.
'Twitter: @telerik
'Facebook: facebook.com/telerik
'=======================================================
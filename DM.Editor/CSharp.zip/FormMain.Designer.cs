﻿namespace Ail.WinForms.Test
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbScriptDataToSend = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonExecuteCmd = new System.Windows.Forms.Button();
            this.buttonExecuteTaskCmd = new System.Windows.Forms.Button();
            this.comboBoxExecuteScript = new System.Windows.Forms.ComboBox();
            this.comboBoxTaskScript = new System.Windows.Forms.ComboBox();
            this.checkBoxAutoBreak = new System.Windows.Forms.CheckBox();
            this.comboBoxEndpointScript = new System.Windows.Forms.ComboBox();
            this.buttonExecuteEndpoint = new System.Windows.Forms.Button();
            this.checkBoxUseInputFile = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxInputFile = new System.Windows.Forms.TextBox();
            this.textBoxFeedback = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonShowMessageFinder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbScriptDataToSend
            // 
            this.tbScriptDataToSend.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbScriptDataToSend.Location = new System.Drawing.Point(12, 168);
            this.tbScriptDataToSend.Multiline = true;
            this.tbScriptDataToSend.Name = "tbScriptDataToSend";
            this.tbScriptDataToSend.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbScriptDataToSend.Size = new System.Drawing.Size(537, 144);
            this.tbScriptDataToSend.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 2;
            // 
            // buttonExecuteCmd
            // 
            this.buttonExecuteCmd.Location = new System.Drawing.Point(12, 15);
            this.buttonExecuteCmd.Name = "buttonExecuteCmd";
            this.buttonExecuteCmd.Size = new System.Drawing.Size(121, 20);
            this.buttonExecuteCmd.TabIndex = 3;
            this.buttonExecuteCmd.Text = "Execute Event";
            this.buttonExecuteCmd.UseVisualStyleBackColor = true;
            this.buttonExecuteCmd.Click += new System.EventHandler(this.buttonExecuteCmd_Click);
            // 
            // buttonExecuteTaskCmd
            // 
            this.buttonExecuteTaskCmd.Location = new System.Drawing.Point(12, 44);
            this.buttonExecuteTaskCmd.Name = "buttonExecuteTaskCmd";
            this.buttonExecuteTaskCmd.Size = new System.Drawing.Size(121, 21);
            this.buttonExecuteTaskCmd.TabIndex = 4;
            this.buttonExecuteTaskCmd.Text = "Execute Task";
            this.buttonExecuteTaskCmd.UseVisualStyleBackColor = true;
            this.buttonExecuteTaskCmd.Click += new System.EventHandler(this.buttonExecuteTaskCmd_Click);
            // 
            // comboBoxExecuteScript
            // 
            this.comboBoxExecuteScript.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxExecuteScript.DisplayMember = "Name";
            this.comboBoxExecuteScript.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxExecuteScript.FormattingEnabled = true;
            this.comboBoxExecuteScript.Location = new System.Drawing.Point(139, 14);
            this.comboBoxExecuteScript.Name = "comboBoxExecuteScript";
            this.comboBoxExecuteScript.Size = new System.Drawing.Size(410, 21);
            this.comboBoxExecuteScript.TabIndex = 5;
            // 
            // comboBoxTaskScript
            // 
            this.comboBoxTaskScript.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxTaskScript.DisplayMember = "Name";
            this.comboBoxTaskScript.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTaskScript.FormattingEnabled = true;
            this.comboBoxTaskScript.Location = new System.Drawing.Point(139, 44);
            this.comboBoxTaskScript.Name = "comboBoxTaskScript";
            this.comboBoxTaskScript.Size = new System.Drawing.Size(410, 21);
            this.comboBoxTaskScript.TabIndex = 6;
            // 
            // checkBoxAutoBreak
            // 
            this.checkBoxAutoBreak.AutoSize = true;
            this.checkBoxAutoBreak.Checked = true;
            this.checkBoxAutoBreak.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxAutoBreak.Location = new System.Drawing.Point(139, 110);
            this.checkBoxAutoBreak.Name = "checkBoxAutoBreak";
            this.checkBoxAutoBreak.Size = new System.Drawing.Size(79, 17);
            this.checkBoxAutoBreak.TabIndex = 7;
            this.checkBoxAutoBreak.Text = "Auto Break";
            this.checkBoxAutoBreak.UseVisualStyleBackColor = true;
            // 
            // comboBoxEndpointScript
            // 
            this.comboBoxEndpointScript.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxEndpointScript.DisplayMember = "Name";
            this.comboBoxEndpointScript.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEndpointScript.FormattingEnabled = true;
            this.comboBoxEndpointScript.Location = new System.Drawing.Point(139, 74);
            this.comboBoxEndpointScript.Name = "comboBoxEndpointScript";
            this.comboBoxEndpointScript.Size = new System.Drawing.Size(410, 21);
            this.comboBoxEndpointScript.TabIndex = 9;
            // 
            // buttonExecuteEndpoint
            // 
            this.buttonExecuteEndpoint.Location = new System.Drawing.Point(12, 74);
            this.buttonExecuteEndpoint.Name = "buttonExecuteEndpoint";
            this.buttonExecuteEndpoint.Size = new System.Drawing.Size(121, 21);
            this.buttonExecuteEndpoint.TabIndex = 8;
            this.buttonExecuteEndpoint.Text = "Execute Endpoint";
            this.buttonExecuteEndpoint.UseVisualStyleBackColor = true;
            this.buttonExecuteEndpoint.Click += new System.EventHandler(this.buttonExecuteEndpoint_Click);
            // 
            // checkBoxUseInputFile
            // 
            this.checkBoxUseInputFile.AutoSize = true;
            this.checkBoxUseInputFile.Location = new System.Drawing.Point(139, 130);
            this.checkBoxUseInputFile.Name = "checkBoxUseInputFile";
            this.checkBoxUseInputFile.Size = new System.Drawing.Size(91, 17);
            this.checkBoxUseInputFile.TabIndex = 10;
            this.checkBoxUseInputFile.Text = "Use Input File";
            this.checkBoxUseInputFile.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(256, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Input File (Abolute Path Name)";
            // 
            // textBoxInputFile
            // 
            this.textBoxInputFile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxInputFile.Location = new System.Drawing.Point(257, 130);
            this.textBoxInputFile.Name = "textBoxInputFile";
            this.textBoxInputFile.Size = new System.Drawing.Size(292, 20);
            this.textBoxInputFile.TabIndex = 11;
            // 
            // textBoxFeedback
            // 
            this.textBoxFeedback.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFeedback.Location = new System.Drawing.Point(12, 339);
            this.textBoxFeedback.Multiline = true;
            this.textBoxFeedback.Name = "textBoxFeedback";
            this.textBoxFeedback.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxFeedback.Size = new System.Drawing.Size(537, 63);
            this.textBoxFeedback.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 320);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Feedback";
            // 
            // buttonShowMessageFinder
            // 
            this.buttonShowMessageFinder.Location = new System.Drawing.Point(12, 109);
            this.buttonShowMessageFinder.Name = "buttonShowMessageFinder";
            this.buttonShowMessageFinder.Size = new System.Drawing.Size(121, 41);
            this.buttonShowMessageFinder.TabIndex = 15;
            this.buttonShowMessageFinder.Text = "Show Message Finder";
            this.buttonShowMessageFinder.UseVisualStyleBackColor = true;
            this.buttonShowMessageFinder.Click += new System.EventHandler(this.buttonShowMessageFinder_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 415);
            this.Controls.Add(this.buttonShowMessageFinder);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxFeedback);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxInputFile);
            this.Controls.Add(this.checkBoxUseInputFile);
            this.Controls.Add(this.comboBoxEndpointScript);
            this.Controls.Add(this.buttonExecuteEndpoint);
            this.Controls.Add(this.checkBoxAutoBreak);
            this.Controls.Add(this.comboBoxTaskScript);
            this.Controls.Add(this.comboBoxExecuteScript);
            this.Controls.Add(this.buttonExecuteTaskCmd);
            this.Controls.Add(this.buttonExecuteCmd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbScriptDataToSend);
            this.Name = "FormMain";
            this.Text = "Script Test Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbScriptDataToSend;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonExecuteCmd;
        private System.Windows.Forms.Button buttonExecuteTaskCmd;
        private System.Windows.Forms.ComboBox comboBoxExecuteScript;
        private System.Windows.Forms.ComboBox comboBoxTaskScript;
        private System.Windows.Forms.CheckBox checkBoxAutoBreak;
        private System.Windows.Forms.ComboBox comboBoxEndpointScript;
        private System.Windows.Forms.Button buttonExecuteEndpoint;
        private System.Windows.Forms.CheckBox checkBoxUseInputFile;
        private System.Windows.Forms.TextBox textBoxInputFile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxFeedback;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonShowMessageFinder;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ail.WinForms.Test
{
    public partial class FormFindMessages : Form
    {
        public FormFindMessages()
        {
            InitializeComponent();
        }

        public class ItemSelectedEventArgs : EventArgs
        {
            public string ContextData { get; set; }
        }

        public event EventHandler<ItemSelectedEventArgs> ItemSelected;

        public event EventHandler<ItemSelectedEventArgs> SetFileNameTargetName;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            var type = typeof(DM.Library.Domain.Interfaces.IDispatchManagerScript);
            var types = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(s => s.GetTypes())
                .Where(p => type.IsAssignableFrom(p));

            cmbMessageTypes.DisplayMember = "Name";
            cmbMessageTypes.DataSource = types.ToList();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            string messageName = cmbMessageTypes.Text;
            string filterText = txtFilterText.Text;

            List<DM.Library.Domain.DispatchMessage> qMessages =
                DM.Library.DataAccess.Adapter.DispatchMessageAdapter.GetPreviousMessageTypes(cmbMessageTypes.Text, 1000);

            if(!string.IsNullOrEmpty(filterText))
                qMessages = qMessages.Where(a => a.Data.Contains(filterText)).ToList();
            
            listViewFoundMessages.Items.Clear();
            foreach(DM.Library.Domain.DispatchMessage msg in qMessages.OrderByDescending( o => o.CreateTime) )
            {
                ListViewItem lviItem = listViewFoundMessages.Items.Add(msg.CreateTime.ToShortDateString() + " " + msg.CreateTime.ToShortTimeString());
                lviItem.SubItems.Add(msg.CreateTime.ToShortDateString() + " " + msg.CreateTime.ToShortTimeString());
                lviItem.SubItems.Add(msg.Status);
                lviItem.SubItems.Add(msg.Data);

                lviItem.Tag = msg;
            }
        }

        public string GetText()
        {
            int index = listViewFoundMessages.SelectedItems[0].SubItems.Count - 1;
            return listViewFoundMessages.SelectedItems[0].SubItems[index].Text;
        }

        private void listViewFoundMessages_DoubleClick(object sender, EventArgs e)
        {
            if (listViewFoundMessages.SelectedItems.Count == 0)
                return;

            Clipboard.SetText(GetText(), TextDataFormat.Text);
            ItemSelected(this, new ItemSelectedEventArgs() { ContextData = GetText() });
        }

        private void buttonPasteText_Click(object sender, EventArgs e)
        {
            ItemSelected(this, new ItemSelectedEventArgs() { ContextData = GetText() });
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ( saveFileDialog1.ShowDialog()  == System.Windows.Forms.DialogResult.OK )
            {
                System.IO.File.WriteAllText(saveFileDialog1.FileName, GetText());
                MessageBox.Show("File saved: " + saveFileDialog1.FileName);

                SetFileNameTargetName(this, new ItemSelectedEventArgs() { ContextData = saveFileDialog1.FileName });
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace Ail.WinForms.Test
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();

            var type = typeof(DM.Library.Domain.Interfaces.IDispatchManagerScript);
            var types = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(s => s.GetTypes())
                .Where(p => type.IsAssignableFrom(p));

            comboBoxExecuteScript.DataSource = types.ToList();

            var typeT = typeof(DM.Library.Domain.Interfaces.IDispatchTaskScript);
            var typesT = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(s => s.GetTypes())
                .Where(p => typeT.IsAssignableFrom(p));

            this.comboBoxTaskScript.DataSource = typesT.ToList();

            var typeE = typeof(DM.Library.Domain.Interfaces.IEndpointScript);
            var typesE = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(s => s.GetTypes())
                .Where(p => typeE.IsAssignableFrom(p));

            this.comboBoxEndpointScript.DataSource = typesE.ToList();

            if(System.IO.File.Exists(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt"))
                tbScriptDataToSend.Text = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt");
        }

        private void buttonExecuteCmd_Click(object sender, EventArgs e)
        {
            System.IO.File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt", tbScriptDataToSend.Text);

            Type t = comboBoxExecuteScript.SelectedItem as Type;

            DM.Library.Domain.Interfaces.IDispatchManagerScript script = (DM.Library.Domain.Interfaces.IDispatchManagerScript) Activator.CreateInstance(t);

            if (checkBoxAutoBreak.Checked)
                System.Diagnostics.Debugger.Break();

            script.Execute(new DM.Library.Domain.ScriptContext(
                new DM.Library.Domain.DispatchMessage() { Data = GetText() })
                {
                    DataMapper = new DM.Library.Mapper(),
                    Queue = new DM.Library.MessageQ.FileWriter()
                });

        }

      

        private void buttonExecuteTaskCmd_Click(object sender, EventArgs e)
        {
            System.IO.File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt", tbScriptDataToSend.Text);

            Type t = comboBoxTaskScript.SelectedItem as Type;

            DM.Library.Domain.Interfaces.IDispatchTaskScript script = (DM.Library.Domain.Interfaces.IDispatchTaskScript)Activator.CreateInstance(t);

            if (checkBoxAutoBreak.Checked)
                System.Diagnostics.Debugger.Break();

            script.Execute(new DM.Library.Domain.TaskContext()
            {
                DataMapper = new DM.Library.Mapper(),
                Queue = new DM.Library.MessageQ.FileWriter()
            });

        }

        public string GetText()
        {
            string text = "";
            if (checkBoxUseInputFile.Checked)
            {
                if (System.IO.File.Exists(textBoxInputFile.Text))
                {
                    text = System.IO.File.ReadAllText(textBoxInputFile.Text);
                }
            }
            else
            {
                text = tbScriptDataToSend.Text;
            }


            return text;
        }

        private void buttonExecuteEndpoint_Click(object sender, EventArgs e)
        {
            System.IO.File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "Recover.txt", tbScriptDataToSend.Text);

            Type t = this.comboBoxEndpointScript.SelectedItem as Type;

            DM.Library.Domain.Interfaces.IEndpointScript script = (DM.Library.Domain.Interfaces.IEndpointScript)Activator.CreateInstance(t);

          
            if (checkBoxAutoBreak.Checked)
                System.Diagnostics.Debugger.Break();

            dynamic obj =
                script.Execute(new DM.Library.Domain.EndpointContext()
                {
                    DataMapper = new DM.Library.Mapper(),
                    Queue = new DM.Library.MessageQ.FileWriter(),
                    Url = "http://localhost",
                    RemoteHost = "localhost",
                    Content = GetText()
                });

            textBoxFeedback.Text = Newtonsoft.Json.JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var db = DM.Library.DataAccess.SqlCommandFactory.GetDatabase("AiDb"))
            {
                string sql = @"
SELECT [Id]
      ,[CreateTime]
      ,[Name]
      ,[Source]
      ,[Data]
      ,[Status]
      ,[ProcessedTime]
      ,[Errors]
      ,[DoNotProcessUntil]
  FROM [mes].[DispatchMessage]
WHERE [Id] = 6074409
";
                var list =
                DM.Library.DataAccess.SqlCommandFactory<DM.Library.Domain.DispatchMessage>
                    .ExecuteQuery(db, true, sql, null).FirstOrDefault();

                System.IO.File.WriteAllText(@"C:\temp\msg.txt", list.Data);


            }
        }

        private void buttonShowMessageFinder_Click(object sender, EventArgs e)
        {
            FormFindMessages msg = new FormFindMessages();

            msg.ItemSelected += msg_ItemSelected;
            msg.SetFileNameTargetName += msg_SetFileNameTargetName;
            msg.Show();

        }

        void msg_SetFileNameTargetName(object sender, FormFindMessages.ItemSelectedEventArgs e)
        {
            textBoxInputFile.Text = e.ContextData;
        }

        void msg_ItemSelected(object sender, FormFindMessages.ItemSelectedEventArgs e)
        {
            tbScriptDataToSend.Text = e.ContextData;
        }        
        
    }
}
